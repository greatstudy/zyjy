create view VIEW_PARAM as
select a.param_id,
       a.param_name,
       a.param_type,
       a.param_value,
       a.state_id,
       b.state_name,
       a.param_desc from c_param a
inner join c_state b on a.state_id = b.state_id
/

