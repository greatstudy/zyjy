create view VIEW_CARD as
select a.card_id,
       a.card_num,
       a.patient_id,
       c.patient_name,
       a.balance,
       a.deposit,
       a.state_id,
       b.state_name,
       a.create_date,
       a.apply_id,
       f.user_name apply_name,
       d.apply_time,
       a.seller_id,
       e.user_name seller_name,
       a.sell_time,
       a.card_desc
        from c_card a
inner join c_state b on a.state_id = b.state_id
left join c_patient c on c.patient_id = a.patient_id
left join c_apply d on d.apply_id = a.apply_id
left join c_user f on f.user_id = d.apply_user_id
left join c_user e on e.user_id = a.seller_id
/

