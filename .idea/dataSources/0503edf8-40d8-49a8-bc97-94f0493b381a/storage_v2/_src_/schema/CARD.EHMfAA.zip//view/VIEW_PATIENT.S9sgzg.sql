create view VIEW_PATIENT as
select a.patient_id,
       a.patient_name,
       a.sex,
       a.age,
       a.native_area,
       a.id_num,
       a.tel,
       a.addr,
       a.patient_desc,
       b.card_num,
       b.balance,
       b.deposit,
       c.state_name
 from c_patient a
inner join c_card b on a.patient_id = b.patient_id
inner join c_state c on b.state_id = c.state_id
/

