create view VIEW_USER as
select a.user_id,
       a.user_name,
       a.account_id,
       a.psw,
       a.dep_id,
       c.param_name dep_name,
       a.role_id,
       d.role_name,
       a.state_id,
       b.state_name,
       a.user_desc
       from c_user a
inner join c_state b on a.state_id = b.state_id
inner join c_param c on c.param_id = a.dep_id
inner join c_role d on a.role_id = d.role_id
/

