create view VIEW_USER_MENU as
select
       a.user_id,
       a.user_name,
       a.account_id,
       g.param_name dep_name,
       c.role_name,
       e.menu_name,
       E.PAGE_HREF,
        h.state_name,
       f.menu_name parent_menu,
       e.menu_order
        from c_user a
inner join c_role c on a.role_id = c.role_id
inner join c_menu_role d on c.role_id = d.role_id
inner join c_menu e on e.menu_id = d.menu_id
inner join c_menu f on f.menu_id = e.parent_id
inner join c_param g on g.param_id = a.dep_id
inner join c_state h on e.state_id = h.state_id
order by e.menu_order
/

