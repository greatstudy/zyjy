create view VIEW_APPLY as
select a.apply_id,
       a.apply_user_id,
       b.user_name apply_name,
       a.apply_num,
       a.apply_time,
       a.state_id,
       c.state_name,
       a.audit_user_id,
       d.user_name audit_name,
       a.audit_time,
       a.apply_desc
       from C_APPLY a
inner join c_user b on a.apply_user_id = b.user_id
inner join c_state c on a.state_id = c.state_id
left join c_user d on a.audit_user_id = d.user_id
/

